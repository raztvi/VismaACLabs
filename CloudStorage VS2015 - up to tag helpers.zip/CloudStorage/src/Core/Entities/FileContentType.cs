﻿namespace Core.Entities
{
    public enum FileContentType
    {
        Invoice,
        Voucher,
        Selfie,
        Report,
        Other
    }
}